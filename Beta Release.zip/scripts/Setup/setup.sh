#!/bin/bash  
sudo cp LinkedIn\ Events.desktop /usr/share/applications/
