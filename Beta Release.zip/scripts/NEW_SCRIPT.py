#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#author: Tarek R.
#date: Jul 12, 2021

from easygui import *
from custom import prepareCookies, EvaluateIfWeAreInLastPage, GetTargetFile, GetUserInputViaPrompt, CallDateTime, SearchEvents
from classes import USER_INPUTS, TIME_SETTINGS, PERSONAL_PROFILE
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium_stealth import stealth
import pandas as pd
from random import randint as rand
from datetime import datetime
from datetime import date
import time
import re
import os
import sys
import csv

pd.options.mode.chained_assignment = None


def StartDriver():
    options = Options()
    options.add_argument("--start-maximized")
    options.add_argument("--no-sandbox")
    options.add_experimental_option("useAutomationExtension", False)
    options.add_experimental_option("excludeSwitches",["enable-automation",'enable-logging'])
    options.add_argument('--ignore-certificate-errors')
    driver=webdriver.Chrome(options=options, executable_path='/home/tarek/my_Projects $$ ****/chromedriver')#'/home/tarek/my_Projects $$ ****/chromedriver' #'/home/ubuntu/Desktop/chromedriver'
    stealth(driver, languages=["en-US", "en"], vendor="Google Inc.", platform="Win32", webgl_vendor="Intel Inc.", fix_hairline=True,)
    prepareCookies(driver)
    return driver

def DropDuplicates(DataFrame):
    ExportDict=DataFrame.drop_duplicates(subset ='ProfileURL',keep = "first", inplace = False)
    return ExportDict

def ReIndex_Attendees_DataFrame(DataFrame:object):
    column_names = ['Scraping Date', 'EventURL', 'EventName', 'TotalAttendees', 'ANZ Atteendees', 'Position And Company', 'Location', 'ProfileURL','Full Name','Total Events Attending', 'Title', 'Company', 'First Name', 'Last Name','Company Name','Position','Company LinkedIn URL']
    df = DataFrame.reindex(columns=column_names)
    return df

def Cleanup_EventsDashboard_Output(outDict_of_EventsDashboard:list,FilteredDict:list):
    ExportDict = CalculateAttendeeGrowth(outDict_of_EventsDashboard,FilteredDict)
    return ExportDict

def ReIndex_Summary_DataFrame(DataFrame:object):
    column_names = ['Scraping Date', 'EventURL', 'EventName', 'TotalAttendees', 'PreviousAttendees', 'Total Growth', 'ANZ Atteendees', 'Event Description', 'Event Date','Beginning Day','Finishing Day', 'Days_from_Begining_Day', 'Days_from_Finishing_Day']
    df = DataFrame.reindex(columns=column_names)
    return df

def Split_Fullname_and_Company(Dic):
    df = pd.DataFrame(Dic)
    df[["First Name","Last Name"]] = ''
    df[["Title","Company"]] = ''
    for i in range(len(df)):
        if df.loc[i, "Full Name"]==None:
            pass
        else:
            FullName = df.loc[i, "Full Name"]
            F = FullName.split(' ')
            if len(F)==1:
                df.loc[i, "First Name"]= F[0]
                df.loc[i, "Last Name"]= None
            elif len(F)>1:
                df.loc[i, "First Name"]= F[0]
                df.loc[i, "Last Name"]= F[1]
            Position_And_Company = df.loc[i, 'Position And Company']
            if ' at ' in Position_And_Company:
                PC = Position_And_Company.split(' at ')
                df.loc[i, "Title"] = PC[0]
                df.loc[i, "Company"] = PC[1]
            else:
                df.loc[i, "Title"] = None
                df.loc[i, "Company"] = None
    return df

def ReadInputCSV(csvfile):
    events=pd.read_csv(csvfile)
    return events

def GetEventName(driver):
    WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.XPATH, '//h1[contains(@class,"title")]')))
    EventName = driver.find_element_by_xpath('//h1[contains(@class,"title")]').text
    return EventName

def checkIfAlreadyJoinedTheEvent(driver):
    time.sleep(4)
    try:
        WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.XPATH, '//button')))
    except:
        pass
    try:
        driver.find_element_by_xpath('//div[contains(@class,"events-social-card-header")]/button').click()
    except:
        pass
    time.sleep(rand(4,7))
    try:
        driver.execute_script("document.getElementsByClassName('lead-gen-modal__submit-button artdeco-button artdeco-button--2')[0].click()")
    except:
        pass

def GetTotalAttendees(driver):
    try:
    	WebDriverWait(driver, 8).until(EC.element_to_be_clickable((By.CLASS_NAME, '//span[contains(@class,"social-proof")]')))
    except:
    	pass
    try:
        TotalAttendees = driver.execute_script('return document.getElementsByClassName("events-live-social-proof__copy-text t-14")[0].innerText')
        T = TotalAttendees.replace(',','')
        totalAttendees = re.search(r'\d+',T)
        return int(totalAttendees.group())
    except:
    	return 'Error Occured'

def GetANZ_Attendees(driver):
    try:
        WebDriverWait(driver, 5).until(EC.presence_of_element_located((By.XPATH, '//div[@class="pb2 t-black--light t-14"]')))
        TotalANZ_Attendees = driver.find_element_by_xpath('//div[@class="pb2 t-black--light t-14"]').text
        T = TotalANZ_Attendees.replace(',','')
        totalANZAttendees = re.search(r'\d+',T)
        return int(totalANZAttendees.group())
    except:
        return 0

def ListEachPagesResult(driver):
    try:
        WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.XPATH, '//div[@class="entity-result__item"]')))
        ParentBoxOfEachProfiles = driver.find_elements_by_xpath('//div[@class="entity-result__item"]') #list
        return ParentBoxOfEachProfiles
    except:
        return 0

# parameters: eachbox
def EvaluateProfileNameVisibility(eachBox):
    try:
        NameOfEachProfile = eachBox.find_element_by_xpath('.//span[@dir="ltr"]/span').text
        return NameOfEachProfile
    except:
        return 0

# parameters: eachBox
def GetName(eachBox):
    Test = EvaluateProfileNameVisibility(eachBox)
    if Test==0:
        print('Name Not Visble')
        Name = 'LinkedIn Member'
        return Name
    else:
        Name = Test
        print(f'Name Visible: {Name}')
        return Name

# parameters: eachBox
def EvaluatePositionAndCompany(eachBox):
    try:
        PositionAndCompany = eachBox.find_element_by_xpath('.//div[contains(@class,"entity-result__primary-subtitle")]').text
        print(PositionAndCompany)
        return PositionAndCompany
    except:
        return 0

# parameters: eachBox
def GetPositionAndCompany(eachBox):
    Test = EvaluatePositionAndCompany(eachBox)
    if Test==0:
        PositionAndCompany = ''
    else:
        PositionAndCompany = Test
    return PositionAndCompany

def EvaluateLocationAvailability(eachBox):
    try:
        Location = eachBox.find_element_by_xpath('.//div[contains(@class,"entity-result__secondary")]').text
        print(Location)
        return Location
    except:
        return 0

def GetLocation(eachBox):
    Test = EvaluateLocationAvailability(eachBox)
    if Test==0:
        Location = ''
    else:
        Location = Test
    return Location

def GetProfileURL(eachBox):
    ProfileURL = eachBox.find_element_by_xpath('.//span/a[@href]').get_attribute('href')
    if 'linkedin.com/in' in ProfileURL:
        return re.sub(r'\?.+','',ProfileURL)
    else:
        return ProfileURL

def EvaluateNextButtonVisibility(driver):
    try:
        WebDriverWait(driver, 2).until(EC.presence_of_all_elements_located((By.XPATH, '//span/a[@href]')))
        NB = driver.find_elements_by_xpath('//span/a[@href]')[-1]
        action = ActionChains(driver)
        NB.location_once_scrolled_into_view
        time.sleep(rand(2,5))
        action.move_to_element(NB).perform()
        WebDriverWait(driver, 2).until(EC.element_to_be_clickable((By.XPATH, '//button[@aria-current="true"]/../following-sibling::li[1]')))
        Test = driver.find_element_by_xpath('//button[@aria-current="true"]/../following-sibling::li[1]')
        print(f'Next Button Found: {Test}')
        NextButtonID=Test.get_attribute('id')
        return NextButtonID
    except:
        return 0

def ClickNextButton(driver):
    Test = EvaluateNextButtonVisibility(driver)
    if Test==0:
        return False
    else:
        driver.execute_script(f"document.getElementById('{Test}').firstElementChild.click()")
        print('Next Button Clicked... Waiting for Next pages result to be visible')
        WebDriverWait(driver, 15).until(EC.presence_of_all_elements_located((By.XPATH, '//span/a[@href]')))

def CheckIfEventEnded(driver):
    try:
        driver.refresh()
        time.sleep(rand(1,3))
        t =rand(2,3)
        driver.execute_script(f"window.scrollBy(0,document.body.scrollHeight/{t})")
        time.sleep(rand(1,3))
        driver.execute_script(f"window.scrollBy(0,document.body.scrollHeight/{t})")
        driver.find_element_by_xpath('//span[text()="Event ended"]')
        print('Ended')
        return 'Ended'
    except:
        print('Not-Ended')
        return 'Not-Ended'

def match(TitlePlusDesc,Keywords):
    for each_keyword in Keywords:
        each_keyword = re.sub(r'^ ',"",each_keyword)
        if each_keyword.lower() in TitlePlusDesc.lower():
            return True
    return False

def GetPreviousAttendees(EventURL,OldDatasetList):
    for o in OldDatasetList:
        if EventURL==o['EventURL']:
            return o['TotalAttendees']

def CalculateAttendeeGrowth(LatestDataSetList:list,OldDatasetList:list):
    NewDataDictList = []
    for j in LatestDataSetList:
        j['PreviousAttendees'] = GetPreviousAttendees(j['EventURL'],OldDatasetList)
        j['Total Growth'] = int(j['TotalAttendees']) - int(j['PreviousAttendees'])
        NewDataDictList.append(j)
    return NewDataDictList

def GenerateANZattendeesLink(EventURL):
    a = EventURL.replace('https://www.linkedin.com/events/','').replace('/','')
    ANZgeocode = '"101452733"%2C"105490917"'
    USAgeocode = '"103644278"'
    GeoEventURL = f'https://www.linkedin.com/search/results/people/?eventAttending="{a}"&geoUrn=%5B{USAgeocode}%5D&origin=FACETED_SEARCH'
    return GeoEventURL

def EventFrontPage(EventURL, driver):
    driver.get(EventURL)
    time.sleep(rand(3, 6))
    EventName = GetEventName(driver)
    print(EventName)
    TotalAttendees = GetTotalAttendees(driver)
    Event_Date = driver.find_element_by_xpath('//div[*[@type="calendar-icon"]]//span').text
    try:
        checkIfAlreadyJoinedTheEvent(driver)
    except:
        print(f"debugger4: checkIfAlreadyJoinedTheEvent")
    Output = {'EventURL':EventURL,'EventName':EventName,'TotalAttendees':TotalAttendees,'Event Date':Event_Date}
    return Output



def ScrapEachProfileFromAttendeesList(EachBox):      
    FullName = GetName(EachBox)
    PositionAndCompany = GetPositionAndCompany(EachBox)
    Location = GetLocation(EachBox)
    ProfileURL = GetProfileURL(EachBox)
    data = {
        'Scraping Date': date.today(),
        'Full Name':FullName,
        'Position And Company':PositionAndCompany,
        'Location':Location,
        'ProfileURL':ProfileURL
        }
    print(f"Debugger3:\n {data}")
    return data

def EachPageOfEventANZattendeesScrap(driver):
    ParentBoxes = ListEachPagesResult(driver)
    result =[]
    if isinstance(ParentBoxes, list):
        time.sleep(rand(3,6))
        for eachBox in range(len(ParentBoxes)):
            INFO = ScrapEachProfileFromAttendeesList(ParentBoxes[eachBox])
            result.append(INFO)
    elif ParentBoxes==0:
        result.append({
        'Scraping Date': date.today(),
        'Full Name':None,
        'Position And Company':None,
        'Location':None,
        'ProfileURL':None
        })
    return result


def ProceedToAttendeeScrap(driver,EventURL,paginationDelay:tuple):   
    AllAttendeesofThisEvent = []
    IsEnded = CheckIfEventEnded(driver)
    if IsEnded=='Not-Ended':
        ANZattendeesLink =GenerateANZattendeesLink(EventURL)
        driver.get(ANZattendeesLink)
        time.sleep(rand(1,3))
        TotalANZ_Atteendees = GetANZ_Attendees(driver)
        while True:
            ANZ_Atteendees = EachPageOfEventANZattendeesScrap(driver)
            [AllAttendeesofThisEvent.append(ANZ_Atteendee) for ANZ_Atteendee in ANZ_Atteendees]
            time.sleep(rand(paginationDelay[0],paginationDelay[1]))
            if EvaluateIfWeAreInLastPage(driver)==True or ClickNextButton(driver)==False:
                break
        [i.update({'ANZ Atteendees':TotalANZ_Atteendees}) for i in AllAttendeesofThisEvent]
    elif IsEnded=='Ended':
        AllAttendeesofThisEvent.append({
        'Scraping Date': date.today(),
        'ANZ Atteendees':None,
        'Full Name':None,
        'Position And Company':None,
        'Location':None,
        'ProfileURL':None})
    else:
        AllAttendeesofThisEvent.append({
        'Scraping Date': date.today(),
        'ANZ Atteendees':None,
        'Full Name':None,
        'Position And Company':None,
        'Location':None,
        'ProfileURL':None})
    return AllAttendeesofThisEvent


def CountDuplicates(ProfileURL,DataFrame,l):
    
    count=0
    if ProfileURL==None or not isinstance(ProfileURL, str) or 'headless' in ProfileURL:
        return None
    for i in range(len(DataFrame)):
        if DataFrame.loc[i, 'ProfileURL'] == None:
            pass
        elif DataFrame.loc[i, 'ProfileURL'] == ProfileURL:
            count=count+1
    return count

def addDuplicateOccurance(DataFrame):
    l=len(DataFrame)
    DataFrame[['Total Events Attending']] = None
    for i in range(len(DataFrame)):
        DataFrame.loc[i, 'Total Events Attending']=CountDuplicates(DataFrame.loc[i, 'ProfileURL'],DataFrame,l)
    return DataFrame



def EvaluateMatchingKeywords(Match_Keywords_with_EventTitle_and_Description:str):
    if not ',' in Match_Keywords_with_EventTitle_and_Description:
        Keywords = [Match_Keywords_with_EventTitle_and_Description,Match_Keywords_with_EventTitle_and_Description]
    elif ',' in Match_Keywords_with_EventTitle_and_Description:
        Keywords = Match_Keywords_with_EventTitle_and_Description.split(',')
    return Keywords

def scroll_to_last_script(driver):
    driver.execute_script('window.scrollBy(0,document.body.scrollHeight)')

def scroll_to_middle(driver):
    driver.execute_script('window.scrollTo(0,document.body.scrollHeight/3)')

def scroll_to_fast(driver):
    driver.execute_script('window.scrollTo(0,0)')
def visitProfile(driver, url:str):
    driver.get(url)
    try:
        WebDriverWait(driver, 15).until(EC.presence_of_element_located((By.XPATH, '//h2')))
    except:
        pass
    time.sleep(rand(3,10))
    scroll_to_last_script(driver)
    time.sleep(rand(2,12))
    scroll_to_middle(driver)
    time.sleep(rand(4,12))
    o = GetCompanyAndTitle(driver)
    return o


def GetCompanyAndTitle(driver):
    try:
        WebDriverWait(driver, 5).until(EC.presence_of_element_located((By.XPATH, '//a[contains(@data-control-name,"company")]//h3/following-sibling::p[2]')))
    except:
        pass
    
    Company = PERSONAL_PROFILE.get_company_name(driver)
    Company_LinkedInURL = PERSONAL_PROFILE.get_company_linkedin_url(driver)
    Title = PERSONAL_PROFILE.get_title(driver)
    output = {'Company Name':Company,'Company LinkedIn URL':Company_LinkedInURL,'Position':Title}
    return output

def Crawl_Individuals(driver,AttendeesDict,pro_scraping_timing:tuple, maximum_run_time:int):
    start = time.time()
    list=[]
    Profiles = AttendeesDict
    k = len(AttendeesDict)
    i=0
    while i+1<k:
        print(Profiles[i]['ProfileURL'])
        if Profiles[i]['ProfileURL']==None or "headless" in Profiles[i]['ProfileURL']:
            list.append({'Company Name':None,'Company LinkedIn URL':None,'Position':None})
        else:
            ProfileInfo = visitProfile(driver, str(Profiles[i]['ProfileURL']))
            time.sleep(rand(pro_scraping_timing[0],pro_scraping_timing[1]))
            print(ProfileInfo)
            list.append(ProfileInfo)
        if time.time()-start>maximum_run_time:
            break
        i+=1
    return list


def InitiateAttendeeCollection():
    csvfile,minimumAttendessRequired,Match_Keywords_with_EventTitle_and_Description = USER_INPUTS.Startup_Mandatory_Inputs()
    
    ImportDF = ReadInputCSV(csvfile)
    if minimumAttendessRequired=='Y':
        DF = ImportDF.loc[ImportDF['TotalAttendees'].astype(int) > 10]
    elif  minimumAttendessRequired == 'N':
        DF = ImportDF
    else:
        exit()
    if Match_Keywords_with_EventTitle_and_Description!='':
        DF = DF[(DF['EventTitle'].str.contains('|'.join(EvaluateMatchingKeywords(Match_Keywords_with_EventTitle_and_Description)))) | (DF['EventShortDesc'].str.contains('|'.join(EvaluateMatchingKeywords(Match_Keywords_with_EventTitle_and_Description))))]
        DF[["Keywords Match"]] = 'True'
    else:
        pass
    FilteredDict = DF.to_dict('records')
    return FilteredDict

def StartCrawl(driver,FilteredDict,paginationDelay):
    outDict_of_EventsDashboard=[]
    outDict_of_Attendees=[]
    N=[]
    for Event in FilteredDict:
        FrontPageObjects = EventFrontPage(Event['EventURL'], driver)
        print(f"\nLogging:::\n FrontPageObjects:\n {FrontPageObjects}")
        ANZ_AttendeesObjects = ProceedToAttendeeScrap(driver,Event['EventURL'],paginationDelay)
        print(f"\nLogging::: ANZ_AttendeesObjects Length: {len(ANZ_AttendeesObjects)}")
        print(f"\nLogging:::\n ANZ_AttendeesObjects items in first dict: {ANZ_AttendeesObjects[0].items()}")
        FrontPageObjects.update({'Scraping Date':date.today(),'ANZ Atteendees':ANZ_AttendeesObjects[0]['ANZ Atteendees'],'Event Description':Event['EventShortDesc']})
        FrontPageObjects.update(CallDateTime(FrontPageObjects['Event Date']))
        for each_dict in ANZ_AttendeesObjects:
            creating_newdict={**FrontPageObjects,**each_dict}
            N.append(creating_newdict)
        outDict_of_EventsDashboard.append(FrontPageObjects)
        #[outDict_of_Attendees.append(k) for k in ANZ_AttendeesObjects]
    return outDict_of_EventsDashboard,N#outDict_of_Attendees


def EventAttendeesGather(driver,paginationDelay:tuple,FilteredDict):
    outDict_of_EventsDashboard,outDict_of_Attendees = StartCrawl(driver,FilteredDict,paginationDelay)
    SummaryExportDict = CalculateAttendeeGrowth(outDict_of_EventsDashboard,FilteredDict)
    Z =ReIndex_Summary_DataFrame(pd.DataFrame(SummaryExportDict)).to_dict('records') 
    return Z, outDict_of_Attendees

def CreateBackups(Attendee:dict, Summary:dict):
    pd.DataFrame(Summary).to_csv('../Summary of Last Run.csv')
    ## [type:AA] = After Events Atendee crawling the raw list of attendees is saved as backup
    ## [type:DD] = After Deduping a new backup is created
    ## [type:SN] = After splitting a final backup is created
    Step =pd.DataFrame(Attendee)
    Step.to_csv('../temp/Backup[type:AA].csv')
    Step0 = addDuplicateOccurance(Step)
    Step1 = DropDuplicates(Step0)
    Step1.to_csv('../temp/Backup[type:DD].csv')
    Step2 = Split_Fullname_and_Company(Step1.to_dict('records'))
    Step2.to_csv('../temp/Backup[type:SN].csv')
    return Step2.to_dict('records')

def Filter_New_Profiles(persons_to_scrap:dict):
    Database=pd.read_csv('../Individuals_Master_File.csv').to_dict('records')
    a = [Database[i]['ProfileURL'] for i in range(len(Database))]
    output=[]
    for i in range(len(persons_to_scrap)):
        if persons_to_scrap[i]['ProfileURL'] in a:
            pass
        else:
            output.append(persons_to_scrap[i])
    
    return output

def RunPersonalProfileCrawl(driver,persons_to_scrap:dict,pro_scraping_timing:tuple, maximum_run_time:int):
    
    org=Filter_New_Profiles(persons_to_scrap)
    org_len = len(org)
    PersonalProfileGather = Crawl_Individuals(driver,org,pro_scraping_timing, maximum_run_time)
    
    output=[]
    i=0
    for i in range(len(PersonalProfileGather)):
        output.append({**org[i],**PersonalProfileGather[i]})
        i+=1
    

    A=['Scraping Date', 'ProfileURL', 'Full Name', 'Position And Company', 'Location', 'First Name', 'Last Name', 'Title', 'Company', 'Company LinkedIn URL']
    M_DB=pd.read_csv('../Individuals_Master_File.csv')
    
    if org_len!=i:
        pd.DataFrame(output).to_csv('../new_attendees.csv')
        NN_DB = pd.DataFrame(output)[A]
        N=NN_DB.loc[NN_DB['ProfileURL']!=None]
        pd.concat([M_DB,N]).to_csv('../Individuals_Master_File.csv',index=False)
        pd.DataFrame(org[len(output):]).to_csv('../Remaining Persons to Scrap (Maximum Time Reached).csv')
    else:
        NN=pd.DataFrame(output)[A]
        N=NN.loc[NN['ProfileURL']!=None]
        pd.concat([M_DB,N]).to_csv('../Individuals_Master_File.csv',index=False)
        ReIndex_Attendees_DataFrame(output).to_csv('../new_attendees.csv')
    
    


if __name__=='__main__':
    functions=GetUserInputViaPrompt('What do you want to do?',"1 -- SearchEvents\n2 -- Scrap Attendees\n\tType 1 or 2:: ")
    
    if functions=='1':
        driver = StartDriver()
        SearchEvents(driver)
    elif functions=='2':
        pro_scraping_timing, paginationDelay, maximum_run_time  = TIME_SETTINGS.time_settings()
        FilteredDict = InitiateAttendeeCollection()
        driver = StartDriver()
        Summary,Attendee = EventAttendeesGather(driver, paginationDelay, FilteredDict)
        persons_to_scrap=CreateBackups(Attendee, Summary)
        RunPersonalProfileCrawl(driver,persons_to_scrap, pro_scraping_timing, maximum_run_time)
    else:
        sys.exit()
    driver.quit()
    os.system('exit')