#!/bin/bash  
cd /home/tarek/Desktop/Stable/Refactoring/scripts
python3 NEW_SCRIPT.py
