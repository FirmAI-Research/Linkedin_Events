import time
from easygui import *
from custom import prepareCookies, EvaluateIfWeAreInLastPage, GetTargetFile, GetUserInputViaPrompt, CallDateTime, SearchEvents
import re
import os
import sys
import csv
import pandas as pd
from random import randint as rand
from datetime import datetime
from datetime import date
class USER_INPUTS:
    def Startup_Mandatory_Inputs():
        csvfile = GetTargetFile('Select input CSV file (with column name')
        sys.exit() if not isinstance(csvfile, str) else print(csvfile)
        minimumAttendessRequired = GetUserInputViaPrompt('Minimum Attendees Requirement','Shall we skip events with less than 10 going?\nType Y/N')
        sys.exit() if minimumAttendessRequired=='' or minimumAttendessRequired==None or isinstance(minimumAttendessRequired, tuple) else print(minimumAttendessRequired)
        Match_Keywords_with_EventTitle_and_Description = GetUserInputViaPrompt('Match Keywords with Title & Description','What keywords shall we scrape events for in the description / title?\nSeparate Keywords by comma\n - Leave blank if you want to scrape all')
        sys.exit() if isinstance(Match_Keywords_with_EventTitle_and_Description, tuple) else print(Match_Keywords_with_EventTitle_and_Description)
        return csvfile,minimumAttendessRequired,Match_Keywords_with_EventTitle_and_Description

class TIME_SETTINGS:
    def easygui_():
        text = "Enter the timing details"
        title = "Settings"
        input_list = [
        "Delay between profiles visiting (Lowest)",
        "Delay between profiles visiting (Highest)",
        "Event attendees list pagination delay (Lowest)",
        "Event attendees list pagination delay (Highest)",
        "Maximum runtime allowed (in hours)"
        ]
        default_list = [20, 40, 5, 12,5]
        output = multenterbox(text, title, input_list, default_list)
        if output==None:
            sys.exit()
        sure=ynbox('Are you sure?', 'Title', ('Yes', 'No'))
        return output, sure
    def configuration():
        config, confirmation = TIME_SETTINGS.easygui_()
        if confirmation==False:
            sys.exit()
        else:
            return config
    def inputToInteger():
        c = TIME_SETTINGS.configuration()
        try:
            inputs=[]
            for i in range(5):
                numbers = int(c[i])
                inputs.append(numbers)
            return inputs
        except:
            return 'Invalid input'
    def time_settings():
        s = TIME_SETTINGS.inputToInteger()
        if s=='Invalid input':
            msgbox("Invalid Inputs!!\nYou must fill all the boxes with numbers only.\nExiting the program now!")
            sys.exit()
        else:
            DelayRange = tuple(s[:2])
            paginationDelay = tuple(s[2:4])
            maximum_run_time = int(s[4])*60*60
            print(f"DelayRange: {DelayRange}\nPagination Delay: {paginationDelay}\nMaximum Run Time: {maximum_run_time}")
            return DelayRange, paginationDelay, maximum_run_time

class PERSONAL_PROFILE:
    def test_company_info_style(driver):
        try:
            driver.find_element_by_xpath('//span[text()="Company Name"]/following-sibling::span/ancestor-or-self::section[contains(@class,"pv-position-entity") and //*[contains(text(),"Present")]]')    
            return True
        except:
            return False
    def get_company_name(driver):
        if PERSONAL_PROFILE.test_company_info_style(driver) == True:
            return driver.find_element_by_xpath('//span[text()="Company Name"]/following-sibling::span').text
        else:
            try:
                Company = driver.find_element_by_xpath('//section[@id="experience-section"]/ul[contains(@class,"pv-profile-section__")]/li//p[2]').text
            except:
                Company = None
            return Company
    def get_company_linkedin_url(driver):
        if PERSONAL_PROFILE.test_company_info_style(driver) == True:
            return driver.find_element_by_xpath('//span[text()="Company Name"]/following-sibling::span/ancestor-or-self::section[contains(@class,"pv-position-entity")]//a').get_attribute('href')
        else:
            try:
                Company_LinkedInURL = driver.find_element_by_xpath('//section[@id="experience-section"]/ul[contains(@class,"pv-profile-section__")]/li//a').get_attribute('href')
            except:
                Company_LinkedInURL = None
            return Company_LinkedInURL
            
    def get_title(driver):
        if PERSONAL_PROFILE.test_company_info_style(driver) == True:
            return driver.find_element_by_xpath('//div[contains(@class,"role-details")]//h3/span[2]').text
        else:
            try:
                Title = driver.find_element_by_xpath('//section[@id="experience-section"]/ul[contains(@class,"pv-profile-section__")]/li//h3').text
            except:
                Title = None
            return Title